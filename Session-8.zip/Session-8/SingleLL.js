        function Node(data) {
            this.data = data;
            this.next = null;
        }

        function SinglyList() {
            this.length = 0;
            this.head = null;
        }


            SinglyList.prototype.add = function (value) {
                var node = new Node(value),
                    currentNode = this.head;

                // an empty list
                if (!currentNode) {
                    this.head = node;
                    this.length++;

                    return node;
                }

                // non-empty list
                while (currentNode.next) {
                    currentNode = currentNode.next;
                }
                currentNode.next = node;
                this.length++;
                return node;
            }

            SinglyList.prototype.remove = function (position) {
                var currentNode = this.head,
                    length = this.length,
                    count = 0,
                    message = {
                        failure: 'Failure: non-existent node in this list.'
                    },
                    beforeNodeToDelete = null,
                    nodeToDelete = null,
                    deletedNode = null;

                //invalid position
                if (position < 0 || position > length) {
                    throw new Error(message.failure);
                }

                //the first node is removed
                if (position === 1) {
                    this.head = currentNode.next;
                    deletedNode = currentNode;
                    currentNode = null;
                    this.length--;
                    return deletedNode;
                }

                // any other node is removed
                while (count < position) {
                    beforeNodeToDelete = currentNode;
                    nodeToDelete = currentNode.next;
                    count++;
                }

                beforeNodeToDelete.next = nodeToDelete.next;
                deletedNode = nodeToDelete;
                nodeToDelete = null;
                this.length--;
                return deletedNode;
            }
            