'use strict';
angular.module('userList').
component('userList', {
    templateUrl :
})