'use strict';
angular.
module('userList').
component('userList', {
    templateUrl: 'user-list/user-list.template.html',
    controller: function UserController($scope, $http) {
        $scope.userData;
        var self = this;
        const jsonFileUrl = 'http://localhost:3000/users';
        
        $http.get(jsonFileUrl).then(function (response) {
            self.users = response.data;
        });

        $scope.postData = function () {
            if($scope.user.id==null){
            $http({
                method: 'POST',
                url: jsonFileUrl,
                data: $scope.user,
                dataType: 'json'
            });
            }
            else{
                $http.put(jsonFileUrl + $scope.user.id, $scope.user);
            }
            window.location.reload();
        };

        $scope.editUser = function(userId){
            $http({
                method: 'GET',
                url: jsonFileUrl + userId
            }).then(function (response){
                $scope.user = response.data;
            });
        } 

        $scope.resetUser = function(){
            $scope.user.id = null;  
            $scope.user.name = null;
            $scope.user.location = null;
            $scope.user.contact = null;
        }
    }
});