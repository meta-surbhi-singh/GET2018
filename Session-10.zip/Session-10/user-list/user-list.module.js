'use strict';
//define the 'userList' module
angular.module('userList',[]);