'use strict';
//the UserManagement module
angular.module('UserManagement',['userList']);