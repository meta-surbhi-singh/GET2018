package com.metacube.training.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.metacube.training.service.EmployeeServiceImpl;


@Controller
public class WelcomeController {

	@Autowired
	EmployeeServiceImpl employeeService;

	@RequestMapping(value="/",method = RequestMethod.GET)
	public String welcome() {
		return "welcome";
	}

	@RequestMapping(value="login", method = RequestMethod.GET)
	public String login(){
		return "login";
	}

	
	@RequestMapping(value="default",method = RequestMethod.GET)
	public String performLogin(HttpServletRequest request){
		if(request.isUserInRole("ROLE_ADMIN")){
			return "redirect:admin/secured";
		}
		else if(request.isUserInRole("ROLE_EMPLOYEE")){
			
			return "redirect:employee/secured";
		}
		else{
			return "redirect:/error";
		}
	}
	
	@RequestMapping(value="/error",method = RequestMethod.GET)
	public String error(){
		return "error";
	}
	
	
}