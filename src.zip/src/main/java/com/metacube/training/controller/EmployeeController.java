package com.metacube.training.controller;



import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.metacube.training.model.Employee;
import com.metacube.training.service.EmployeeServiceImpl;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeServiceImpl employeeService;

	//	@RequestMapping(value = "/login", method = RequestMethod.GET)
	//	public String login() {
	//		return "employee/login";
	//	}

	@RequestMapping(value = "/secured", method = RequestMethod.GET)
	public String login(Principal principal,Model model) {
		System.out.println("inside employee controller");
		String email = principal.getName();
		System.out.println(email);
		model.addAttribute("employee", employeeService.getEmployeeByEmail(email));
		return "employee/dashboard";
	}


	@RequestMapping(value = "/editProfile", method = RequestMethod.GET)
	public ModelAndView edit(Model model, @RequestParam("id") int id) {
		model.addAttribute("employee", employeeService.getEmployeeById(id));
		return new ModelAndView("employee/editProfile");
	}

	//@RequestMapping(value = "/logout" , method = RequestMethod.GET)
//	public ModelAndView logout() {
//		return new ModelAndView("redirect:../");
//	}

	@RequestMapping(value = "/saveProfile", method = RequestMethod.POST)
	public String saveProfile(@ModelAttribute("employee") Employee employee) {
		employeeService.updateEmployee(employee);
		return "employee/login";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public String forgotPassword() {
		return "employee/forgotPassword";
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public String resetPassword(Model model,@RequestParam("email") String email) {
		employeeService.sendResetLink(email);
		System.out.println(email);
		return "employee/resetPassword";
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search() {
		return "employee/search";
	}

	@RequestMapping(value = "/searchEmployee", method = RequestMethod.POST)
	public String searchEmployee(Model model, @RequestParam("name") String name) {
		model.addAttribute("employees", employeeService.searchEmployee(name));
		model.addAttribute("name", name);
		return "employee/searchEmployee";
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	public String back() {
		return "redirect:./login";
	}


}
