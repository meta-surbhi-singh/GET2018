package com.metacube.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.metacube.training.model.Role;

@Repository
@Transactional
public interface RoleRepository extends JpaRepository<Role, Integer>{
	List<Role> findByEmail(String email);
}
