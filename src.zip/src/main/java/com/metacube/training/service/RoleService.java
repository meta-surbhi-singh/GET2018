package com.metacube.training.service;

import java.util.List;

import com.metacube.training.model.Role;

public interface RoleService {

	List<Role> getInfoByEmail(String email);
}
