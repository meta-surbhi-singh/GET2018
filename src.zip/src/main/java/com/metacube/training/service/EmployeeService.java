package com.metacube.training.service;

import java.util.List;

import com.metacube.training.model.Employee;

public interface EmployeeService {

	boolean createEmployee(Employee employee);

	boolean updateEmployee(Employee employee);

	Employee getEmployeeById(int id);

	boolean deleteEmployee(int id);

	List<Employee> getAllEmployee();

	Employee getEmployeeByEmail(String email);

	boolean employeeAuthenticated(String email, String password);

	void sendResetLink(String email);

	List<Employee> searchEmployee(String name);
	
	

}
