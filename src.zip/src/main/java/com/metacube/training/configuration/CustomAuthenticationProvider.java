package com.metacube.training.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Component;

import com.metacube.training.model.Role;
import com.metacube.training.service.EmployeeService;
import com.metacube.training.service.EmployeeServiceImpl;
import com.metacube.training.service.RoleService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    EmployeeService employeeService;
    
    @Autowired
    RoleService roleService;
    


    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
    	System.out.println(employeeService);
    	UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
    	System.out.println("inside authenticate function");
    	System.out.println(String.valueOf(auth.getPrincipal()));
    	System.out.println(String.valueOf(auth.getCredentials()));
		String email = String.valueOf(auth.getPrincipal());
		String password = String.valueOf(auth.getCredentials());
		System.out.println(email);
		System.out.println(password);

		if (!(employeeService.employeeAuthenticated(email, password))) {
			throw new BadCredentialsException(
					"External system authentication failed");
		}
		System.out.println("employee" + employeeService.getEmployeeByEmail(email).getName());

		List<GrantedAuthority> roles = new ArrayList<>();
		List<Role> roleList = roleService.getInfoByEmail(email);

		for (Role role : roleList) {
			System.out.println("role:" + role.getRole());
			roles.add(new SimpleGrantedAuthority(role.getRole()));
		}
		return new UsernamePasswordAuthenticationToken(email, password, roles);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

    
}