package com.metacube.training;

public class SpringScopeExample {
	private String message;

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/**
	 * prints the message
	 */
	public void getMessage() {
		System.out.println("Your message : " + message);
	}

}
