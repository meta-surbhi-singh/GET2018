package com.metacube.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		System.out.println("for the singleton scope");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("BeansSingleton.xml");
		SpringScopeExample springScopeA = (SpringScopeExample) ctx.getBean("springScopeExample");
		springScopeA.setMessage("Hello i'm singleton object A");
		springScopeA.getMessage();
		
		SpringScopeExample springScopeB = (SpringScopeExample) ctx.getBean("springScopeExample");
		springScopeB.getMessage();
		
		System.out.println("\n\n for the prototype scope");
		ctx = new ClassPathXmlApplicationContext("BeansPrototype.xml");
		SpringScopeExample springScopeC = (SpringScopeExample) ctx.getBean("springScopeExample");
		springScopeC.setMessage("Hello i'm object prototype object C");
		springScopeC.getMessage();
		
		SpringScopeExample springScopeD = (SpringScopeExample) ctx.getBean("springScopeExample");
		springScopeD.getMessage();
	}

}
