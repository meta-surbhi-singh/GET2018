package com.metacube.training;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionImplementation {
	List<String> nameList;
	Set<String>  nameSet;
	Map<Integer, String>  nameMap;
	/**
	 * @return the nameList
	 */
	public List<String> getNameList() {
		return nameList;
	}
	/**
	 * @param nameList the nameList to set
	 */
	public void setNameList(List<String> nameList) {
		this.nameList = nameList;
	}
	/**
	 * @return the nameSet
	 */
	public Set<String> getNameSet() {
		return nameSet;
	}
	/**
	 * @param nameSet the nameSet to set
	 */
	public void setNameSet(Set<String> nameSet) {
		this.nameSet = nameSet;
	}
	/**
	 * @return the nameMap
	 */
	public Map<Integer, String> getNameMap() {
		return nameMap;
	}
	/**
	 * @param nameMap the nameMap to set
	 */
	public void setNameMap(Map<Integer, String> nameMap) {
		this.nameMap = nameMap;
	}

	// prints and returns all the elements of the list.
	   public List<String> printNameList() {
	      System.out.println("List Elements :"  + nameList);
	      return nameList;
	   }
	   
	// prints and returns all the elements of the Set.
	   public Set<String> printNameSet() {
	      System.out.println("Set Elements :"  + nameSet);
	      return nameSet;
	   }
	   
	   // prints and returns all the elements of the Map.
	   public Map<Integer, String> printNameMap() {
	      System.out.println("Map Elements :"  + nameMap);
	      return nameMap;
	   }
}
