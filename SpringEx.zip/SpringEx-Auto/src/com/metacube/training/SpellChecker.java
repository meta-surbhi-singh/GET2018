package com.metacube.training;

public class SpellChecker {

	public SpellChecker() {
		System.out.println("Inside SpellChecker constructor.");
	}
	public String checkSpelling() {
		return "Checking spelling";
	}
}
