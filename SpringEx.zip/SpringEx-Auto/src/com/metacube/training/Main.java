package com.metacube.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	@SuppressWarnings("resource")
	public static void main(String args[]) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		TextEditor textEditor = (TextEditor) ctx.getBean("textEditor");
		textEditor.check();
	}

}
