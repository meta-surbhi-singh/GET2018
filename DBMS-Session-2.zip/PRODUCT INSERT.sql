INSERT INTO PRODUCT
VALUES(34,'TROUSER', '2005-11-07' ,1005.50,40,'A revolution in sizing, fit and thinking');
INSERT INTO PRODUCT
VALUES(40,'SHIRT','2015-07-10',1000.50,60,'Our T-shirts are made of the most comfortable');
INSERT INTO PRODUCT
VALUES(43,'TOP','2018-10-07',1500.50,55,'polyester tops for a fashinable you');
INSERT INTO PRODUCT
VALUES(45,'BOX','2018-12-28',250.50 ,40,'multifunctional boxes');
INSERT INTO PRODUCT
VALUES(60,'PEN-STAND','1995-10-07',60.70,40,'available in 4 colours of regular size');
INSERT INTO PRODUCT
VALUES(65 ,'CHOCOLATE', CURDATE(), 50.00 ,100, 'a favourite among children, this is the best dessert you can have');
INSERT INTO PRODUCT
VALUES(74, 'JUICE', CURDATE(), 70.50 ,40 ,'delicious juices made of fresh fruits');
INSERT INTO PRODUCT
VALUES(82, 'ICE-CREAM' ,CURDATE(), 200.50, 60, 'a frozen dessert made with cream or milk, sugar, flavoring, and sometimes eggs.');
INSERT INTO PRODUCT
VALUES(83, 'CURTAINS' ,CURDATE(), 1000.50, 15 ,'available both blind curtains and sun-light curtains');
INSERT INTO PRODUCT
VALUES(85, 'BEDSHEET', CURDATE(), 700.50, 10 ,'king-size, queen-size bedsheets and beautiful prints');
INSERT INTO PRODUCT
VALUES(87, 'SHAMPOO', CURDATE() ,150.00, 50, 'for gorgeous hair and a healthy mane');
INSERT INTO PRODUCT
VALUES(90, 'BISCUITS', CURDATE() ,60.00, 20 ,'tasty yet  healthy biscuits for children');
INSERT INTO PRODUCT
VALUES(91, 'MAGGI-NOODLES',CURDATE(), 40.00, 40 ,'2-minutes noodles');

SELECT * FROM PRODUCT;