CREATE DATABASE STORE_FRONT;
USE STORE_FRONT;
CREATE TABLE CATEGORY(ID INTEGER NOT NULL,
                      Title VARCHAR(50), 
                      Parent_ID INTEGER, 
                      PRIMARY KEY(ID), 
                      FOREIGN KEY (Parent_ID) REFERENCES CATEGORY(ID));
                      
CREATE TABLE PRODUCT (ID INTEGER NOT NULL,
                      Title VARCHAR(100) , 
                      DATE date, Price FLOAT ,  
                      Quantity INTEGER, PRIMARY KEY (ID));
                      
CREATE TABLE PRODUCT_CATEGORY(Product_ID INTEGER NOT NULL, 
                              Category_ID INTEGER NOT NULL, 
                              FOREIGN KEY(Product_ID) REFERENCES PRODUCT(ID), 
                              FOREIGN KEY (Category_ID) REFERENCES CATEGORY(ID));
                              
CREATE TABLE SHOPPER (ShopperID INTEGER NOT NULL, 
                      Name VARCHAR(100), 
                      Date_of_birth DATE,
                      PRIMARY KEY(ShopperID));
                      
CREATE TABLE SHIPPING_ADDRESS(Address_ID INTEGER NOT NULL, 
                              Shopper_ID INTEGER NOT NULL,
                              Address VARCHAR(100), 
                              Pincode BIGINT, 
                              City VARCHAR(50),
                              State VARCHAR(100),
                              Country VARCHAR(100),
                              PRIMARY KEY(Address_ID), 
                              FOREIGN KEY (Shopper_ID) REFERENCES SHOPPER(ShopperID) );
                              
CREATE TABLE ORDERS (ID INTEGER NOT NULL, 
                     Shopper_ID INTEGER NOT NULL, 
                     Shipping_Address_ID INTEGER NOT NULL, 
                     Orders_Date DATE, Bill FLOAT, PRIMARY KEY(ID), 
                     FOREIGN KEY (Shopper_ID) REFERENCES SHOPPER(ShopperID),
                     FOREIGN KEY (Shipping_Address_ID) REFERENCES SHIPPING_ADDRESS(Address_ID));
                     
CREATE TABLE PRODUCT_ORDERS(Product_ID INTEGER NOT NULL, 
                            Order_ID INTEGER NOT NULL,
                            FOREIGN KEY(Product_ID) REFERENCES PRODUCT(ID),
                            FOREIGN KEY (Order_ID) REFERENCES ORDERS(ID));
                   
CREATE TABLE PRODUCT_IMAGE(Image_ID INTEGER NOT NULL, 
                           Product_ID INTEGER NOT NULL,
                           PRIMARY KEY(Image_ID),
                           FOREIGN KEY(Product_ID) REFERENCES PRODUCT(ID));
SHOW TABLES;

ALTER TABLE PRODUCT ADD Description VARCHAR(200);
ALTER TABLE PRODUCT_ORDERS ADD  Quantity_ordered INTEGER;
ALTER TABLE PRODUCT_ORDERS ADD Status ENUM('PLACED','SHIPPED','DELIVERED','CANCELLED','RETURNED','EXCHANGED');
ALTER TABLE PRODUCT_ORDERS DROP Status;
SELECT * FROM PRODUCT_ORDERS;
SELECT * FROM USER;
