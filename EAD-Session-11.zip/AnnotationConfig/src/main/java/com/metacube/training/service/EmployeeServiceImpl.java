package com.metacube.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.metacube.training.dao.EmployeeDaoImpl;
import com.metacube.training.model.Employee;
@Component
@Service
public class EmployeeServiceImpl{
	
	@Autowired
	EmployeeDaoImpl employeeDao;

	public boolean createEmployee(Employee employee) {
		return employeeDao.create(employee);
	}

	public boolean updateEmployee(Employee employee) {
		return employeeDao.update(employee);
	}

	
	public Employee getEmployeeById(int id) {
		return employeeDao.getEmployeeByID(id);
	}


	public boolean deleteEmployee(int id) {
		Employee employee = employeeDao.getEmployeeByID(id);
		return employeeDao.delete(employee);
	}

	public List<Employee> getAllEmployee() {
		return employeeDao.getAll();
	}

	public Employee getEmployeeByEmail(String email) {
		return employeeDao.getEmployeeByEmail(email);
	}

	

}
