package com.metacube.training.dao;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.metacube.training.model.Employee;
@Component
@Repository
@Transactional
public class EmployeeDaoImpl {

	//private JdbcTemplate jdbcTemplate;
	
	/*@Autowired
	public MySQLEmployeeDao(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}*/
	
	@Autowired
	private SessionFactory sessionFactory;
	
	private final String selectAllQuery = "from Employee";
	private final String updateQuery = "update Employee set employee_id=:employeeId,name=:name,dob=:dob,gender=:gender,contact_no=:contactNo,email_id=:emailId,password=:password";
	private final String deleteQuery = "delete from Employee where employee_id=:employeeId";
	private final String selectById = "from Employee where employee_id=:employeeId";
	private final String selectByEmail = "from Employee where email_id=:emailId";
	
	public List<Employee> getAll() {
		TypedQuery<Employee> query = sessionFactory.getCurrentSession().createQuery(selectAllQuery);
		return query.getResultList();
	}

	public boolean create(Employee employee) {
		TypedQuery<Employee> query = (TypedQuery<Employee>) sessionFactory.getCurrentSession().save(employee);
		return true;
	}

	public boolean update(Employee employee) {
		TypedQuery<Employee> query = sessionFactory.getCurrentSession().createQuery(updateQuery);
		query.setParameter("employeeId", employee.getEmployeeId());
		query.setParameter("name", employee.getName());
		query.setParameter("dob", employee.getDateOfBirth());
		query.setParameter("gender", employee.getGender());
		query.setParameter("contactNo", employee.getContactNo());
		query.setParameter("email_id", employee.getEmailId());
		query.setParameter("password", employee.getPassword());
		return query.executeUpdate() > 0;
	}

	public boolean delete(Employee employee) {
		TypedQuery<Employee> query = sessionFactory.getCurrentSession().createQuery(deleteQuery);
		query.setParameter("employeeId", employee.getEmployeeId());
		return query.executeUpdate() > 0;
	
	}

	public Employee getEmployeeByID(int id) {
		TypedQuery<Employee> query = sessionFactory.getCurrentSession().createQuery(selectById);
		query.setParameter("employeeId", id);
		return query.getSingleResult();
	}

	public Employee getEmployeeByEmail(String email) {
		TypedQuery<Employee> query = sessionFactory.getCurrentSession().createQuery(selectByEmail );
		query.setParameter("email", email);
		return query.getSingleResult();
	}
	
}
