package com.metacube.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.metacube.training.model.Employee;
import com.metacube.training.service.EmployeeServiceImpl;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeServiceImpl employeeService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "employee/login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(Model model,  @RequestParam("email") String email) {
		model.addAttribute("employee", employeeService.getEmployeeByEmail(email));
		return "employee/dashboard";
	}
	
	
	@RequestMapping(value = "/editProfile", method = RequestMethod.GET)
	public ModelAndView edit(Model model, @RequestParam("id") int id) {
		model.addAttribute("employee", employeeService.getEmployeeById(id));
		return new ModelAndView("employee/editProfile");
	}
	
	@RequestMapping(value = "/logout" , method = RequestMethod.GET)
	public ModelAndView logout() {
		return new ModelAndView("redirect:../");
	}
	
	@RequestMapping(value = "/saveProfile", method = RequestMethod.POST)
		public String saveProfile(@ModelAttribute("employee") Employee employee) {
			employeeService.updateEmployee(employee);
			return "employee/login";
		}
	

}
