		var errorMap = new Map();
		

		function send() {
			var form = document.getElementById("user-signup");
			var message = "ERROR MESSAGE...!! \n";
			if(validateFirstName() && validateLastName() && validateEmail() && validatePhone()){
			alert("GOOD JOB..!!");
			if(localStorage){
				localStorage.clear();
					for(var x = 0; x < form.length; x++){ 
						localStorage.setItem(form.elements[x].name,form.elements[x].value);
					}
			}
			}
			else{
				var keys = errorMap.keys();
			for(var key of keys){
				if(errorMap.get(key) == ""){
					message +=  key + " can't be empty \n" ;
				}else{
			message += key + " can't be " + errorMap.get(key) + "\n"; }
				}
			alert(message);
			}
			}
			
			
		
			function validateFirstName(){
			var first_nm = document.getElementById("firstname");
			var pattern = new RegExp("^[a-zA-Z][a-zA-Z0-9'_]+$")
			if(!pattern.test(first_nm.value)){
			first_nm.style.borderColor = "#7c0606";
			errorMap.set("First name",first_nm.value);
			return false;
			}
			else {
			first_nm.style.borderColor = "#5e8f31";
			
			return true;}
			}
			
			function validateLastName() { 
			var last_nm = document.getElementById("lastname");
			var pattern = new RegExp("^[a-zA-Z][a-zA-Z0-9_]+$")
			if(!pattern.test(last_nm.value)){
			last_nm.style.borderColor = "#7c0606";
			errorMap.set("Last name",last_nm.value);
			return false;
			}else {
			last_nm.style.borderColor = "#5e8f31";
			
			return true;}
			}
			
			function validateEmail(){
			var pattern = new RegExp("^[a-zA-Z][a-zA-Z0-9.+-]*@[a-zA-Z]+.[a-zA-Z0-9.-]+$");
			var str = document.getElementById("e-mail");
			if(!pattern.test(str.value)) {
			str.style.borderColor = "#7c0606";
			errorMap.set("E-mail",str.value);
			return false;
			} else {
			str.style.borderColor = "#5e8f31";
			return true;
			}
			}
			
	
			function validatePhone(){
			var pattern = new RegExp("^[0-9]{10}$");
			var str = document.getElementById("phone");
			if(!pattern.test(str.value)){
			str.style.borderColor = "#7c0606";
			errorMap.set("Phone",str.value);
			return false;
			}
			else{
			str.style.borderColor = "#5e8f31";
			return true;
			}
			}
			
			function validateZipcode(){
				var pattern = new RegExp("^[0-9]{6}$");
				var str = document.getElementById("zipcode");
				if(!pattern.test(str.value)){
					str.style.borderColor = "#7c0606";
					errorMap.set("Zipcode",str.value);
					return false;
				}
				else{
					str.style.borderColor = "#5e8f31";
				}
			}

			function validateUrl(){
				var  pattern = new RegExp("^https?://[a-zA-Z0-9_]+.[a-zA-Z0-9_]+.?[a-zA-Z0-9_]+$");
				var str = document.getElementById("url");
				if(!pattern.test(str.value)){
					str.style.borderColor = "#7c0606";
					errorMap.set("Domain name",str.value);
					return false;
				}
				else{
					str.style.borderColor = "#5e8f31";
				}
			}
		
			function stateChange(){
				var state = document.getElementById("state").value;
				if("Rajasthan" == state){
					removeDynamicElements();
					addWebsiteField();
					addProjectDescription();
				}
				else if ("Haryana" == state){
					removeDynamicElements();
					addZipcodeField();
					addHostingField();
				}
				else if("Maharashtra" == state){
					removeDynamicElements();
					addZipcodeField();
					addProjectDescription();
				}
			}

			
			

			function addWebsiteField(){
				var website = document.createElement("div");
				website.className = "form-fields";
				website.id = "website-div";
				website.innerHTML = "<label>Website or domain name</label><div class = 'form-input-fields'><i class='fas fa-globe-americas'></i><input type = 'text' class = 'input-field' id = 'url' name = 'Website or domain name' placeholder='(http:\\abc.xyz.com)' onkeyup = 'validateUrl()'/></div>"
				var form = document.getElementById("user-signup");
				form.insertBefore(website,form.lastElementChild);
			}
			
			function addProjectDescription(){
				var project = document.createElement("div");
				project.className = "form-fields";
				project.id = "project-div";
				project.innerHTML = "<label>Project Description</label><div class = 'form-input-fields'><i class='fas fa-pencil-alt'></i><textarea class = 'input-field' rows ='3' cols='width' id = 'project' name = 'Project Description' placeholder = 'Project Description' ></textarea></div>"
				
				var form = document.getElementById("user-signup");
				form.insertBefore(project,form.lastElementChild);
			}
			function addZipcodeField(){
				var zipcode = document.createElement("div");
				zipcode.className = "form-fields";
				zipcode.id = "zipcode-div"
				zipcode.innerHTML = "<label>Zip Code</label><div class = 'form-input-fields'><i class='fas fa-home'></i><input type = 'text' class = 'input-field' name = 'zipcode' id = 'zipcode' placeholder='Zip Code' onkeyup = 'validateZipcode()' /></div>"
				
		
			var form = document.getElementById("user-signup");
				form.insertBefore(zipcode,form.lastElementChild);

			}
			function addHostingField(){
				var hosting = document.createElement("div");
				hosting.className = "form-fields";
				hosting.id = "hosting-div";
				hosting.innerHTML = " <label>Do you have hosting?</label><div class = 'form-radio-fields'><label>Yes</label> <input type='radio' name='host' value='Yes'> <br><label>No</label> <input type='radio' name='host' value='No'></div>"

				var form = document.getElementById("user-signup");
				form.insertBefore(hosting,form.lastElementChild);
			}

			function removeDynamicElements(){
				var form = document.getElementById("user-signup");
				var website = document.getElementById("website-div");
				var project = document.getElementById("project-div");
				var zipcode = document.getElementById("zipcode-div");
				var hosting = document.getElementById("hosting-div");
				 if(form.contains(website)){
					 form.removeChild(website);
				  }
				  if(form.contains(project)){
					form.removeChild(project);
				 }
				 if(form.contains(zipcode)){
					form.removeChild(zipcode);
				 }
				 if(form.contains(hosting)){
					form.removeChild(hosting);
				 }
			}