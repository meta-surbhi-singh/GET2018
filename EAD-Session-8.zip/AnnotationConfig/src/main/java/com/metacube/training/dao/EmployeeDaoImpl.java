package com.metacube.training.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.training.mappers.EmployeeMapper;
import com.metacube.training.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	private final String selectAll = "select * from employees";

	@Override
	public List<Employee> getlist() {
		return jdbcTemplate.query(selectAll, new EmployeeMapper());
	}

	@Override
	public Employee insert(Employee employee) {
		return employee;
		//return new 
				//jdbcTemplate.queryForObject(sql, rowMapper) (insertQuery, new Object{1,2,3}, new EmployeeMapper());
	}

	@Override
	public int update(Employee t) {
		return 0;
		
	}

	@Override
	public void delete(Employee t) {
	}

	@Override
	public Employee search(String name) {
		return null;
	}

}
