package com.metacube.training.service;

import java.util.List;

import com.metacube.training.model.Skill;

public interface SkillService {
	Skill getSkillById(int id);

	List<Skill> getAllSkill();

	boolean deleteSkill(int id);

	boolean updateSkill(Skill skill);

	boolean createSkill(Skill skill);
}
