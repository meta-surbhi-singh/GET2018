package com.metacube.training.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.training.mappers.SkillMapper;
import com.metacube.training.model.Skill;

@Repository
public class SkillDAOImpl implements SkillDAO{
	@Autowired 
	JdbcTemplate jdbcTemplate;
	
	private final String selectQuery = "select * from skill where id = ?";
	private final String selectAll = "select * from skill";

	@Override
	public Skill getSkillById(int id) {
		return jdbcTemplate.queryForObject(selectQuery, new Object[] {id}, new SkillMapper());
	}

	@Override
	public List<Skill> getAllSkill() {
		return jdbcTemplate.query(selectAll, new SkillMapper());
		}

	@Override
	public boolean deleteSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean createSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
