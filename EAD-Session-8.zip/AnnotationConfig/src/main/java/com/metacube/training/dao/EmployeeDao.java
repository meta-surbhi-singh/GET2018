package com.metacube.training.dao;

import java.util.List;

import com.metacube.training.model.Employee;

public interface EmployeeDao {

	public List<Employee> getlist();

	public Employee insert(Employee employee);

	public int update(Employee employee);

	public void delete(Employee employee);
	
	public Employee search(String name);
}
