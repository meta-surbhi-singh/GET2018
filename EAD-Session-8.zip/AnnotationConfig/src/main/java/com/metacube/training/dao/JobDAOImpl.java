package com.metacube.training.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Repository;

import com.metacube.training.mappers.JobMapper;
import com.metacube.training.model.Job;

@Repository
public class JobDAOImpl implements JobDAO{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private final String selectQuery = "select * from job where id = ?";
	private final String selectAll = "select * from job";
	
	@Override
	public Job getJobById(int id) {
		return jdbcTemplate.queryForObject(selectQuery, new Object[] {id}, new JobMapper());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Job> getAllJobs() {
		return (List<Job>) jdbcTemplate.queryForObject(selectAll, new JobMapper());
	}

	@Override
	public boolean deleteJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean createJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

}
