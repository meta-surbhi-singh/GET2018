package com.metacube.training.model;

public class Skill {
	private int id;
	private String title;

	// Getter Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String name) {
		this.title = name;
	}
	// Getters Setters END
}
