package com.metacube.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.metacube.training.dao.EmployeeDaoImpl;
import com.metacube.training.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDaoImpl employeeDao;

	@Override
	public boolean createEmployee(Employee employee) {
		return employeeDao.insert(employee) != null;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		return employeeDao.update(employee) > 0;
	}

	@Override
	public Employee searchEmployee(String name) {
		return employeeDao.search(name);
	}

	@Override
	public Object getEmployeeByCode(int id) {
		// TODO Auto-generated method stub
		return null;
	}
 

}
