package com.metacube.training.service;

import com.metacube.training.model.Employee;

public interface EmployeeService {
	
	public boolean updateEmployee(Employee employee);
	public Employee searchEmployee(String name);
	public boolean createEmployee(Employee employee);
	public Object getEmployeeByCode(int id);

}
