package com.models;

public class Category  {
	
    private int id;
	private String name;
	

	/**
	 * 
	 */
	public Category() {
	}

	/**
	 * @param id
	 * @param name
	 */
	public Category(int id, String name) {
		this.id = id;
		this.name = name;
	}

	// Constructor to initialize attributes
	public Category(String name) {

		this.name = name;

	}

	// Getter START
	public String getName() {
		return name;
	}
	// Getter END

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
