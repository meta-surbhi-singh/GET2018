package com.models;

public class Advertisement {
	private int id;
	private int category_id;
	private String title;
	
	/**
	 * 
	 */
	public Advertisement() {
	}



	/**
	 * @param id
	 * @param category_id
	 * @param title
	 */
	public Advertisement(int id, int category_id, String title) {
		this.id = id;
		this.category_id = category_id;
		this.title = title;
	}

	

	// Constructor to initialize the attributes
	public Advertisement(int category_id, String title) {
		this.category_id = category_id;
		this.title = title;
	}

	// START Getter
	public int getCategory_id() {
		return category_id;
	}

	public String getTitle() {
		return title;
	}
	// END Getter

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param category_id the category_id to set
	 */
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

}
