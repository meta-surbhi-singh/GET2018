package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {

	/**
	 * Function to get database connection
	 * 
	 * @return connection object
	 */
	public static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName( "com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restdatabase", "root", "database");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
}
