package com.dao;

public interface ICategoryDao extends IBaseDao<com.models.Category> {
	
	public boolean CheckCategory(String name);
	
	public void deleteById(int id);
}
