package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.facade.CategoryFacade;
import com.models.Advertisement;
import com.view.AdvertisementView;

public class AdvertisementQueryExecution implements IAdvertisementDao {

	public static AdvertisementQueryExecution advertisement = new AdvertisementQueryExecution();

	CategoryFacade categoryfacade = CategoryFacade.getInstance();

	public static AdvertisementQueryExecution getInstance() {
		return advertisement;
	}

	Connection connection;

	@Override
	public List<Advertisement> getlist() {
		List<Advertisement> listOfAdvertisement = new ArrayList<Advertisement>();

		String selectQuery = "SELECT * FROM advertisement";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(selectQuery);

			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				int id = resultSet.getInt("ID");
				int category_id = resultSet.getInt("CATEGORY_ID");
				String name = resultSet.getString("ADVERTISEMENT_TITLE");

				Advertisement advertisement = new Advertisement(category_id, name);
				advertisement.setId(id);

				listOfAdvertisement.add(advertisement);
			}
			connection.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

		return listOfAdvertisement;
	}

	@Override
	public void insert(Advertisement advertisement) {
		String insertQuery = "INSERT INTO advertisement(category_id,advertisement_title)VALUES(?,?) ";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(insertQuery);

			statement.setInt(1, advertisement.getCategory_id());

			statement.setString(2, advertisement.getTitle());

			statement.executeUpdate();

			connection.close();
		} 
		catch (SQLException e) { 
			e.printStackTrace();
		}

	}

	@Override
	public void update(Advertisement advertisement) {
		String updateQeury = "UPDATE advertisement SET ADVERTISEMENT_TITLE ='" + advertisement.getTitle() +"' WHERE ID = " + advertisement.getId();

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(updateQeury);
			statement.executeUpdate();
			connection.close();
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Advertisement t) {
		// delete with any attribute
	}

	@Override
	public boolean CheckAdvertisement(String name) {
		boolean status = false;
		String checkQuery = "SELECT * FROM advertisement WHERE  advertisement_title = '" + name + "'";

		connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(checkQuery);

			ResultSet result = statement.executeQuery();

			if (result.next()) {
				status = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return status;
	}

	@Override
	public List<AdvertisementView> getListById(int category_id) {
		List<AdvertisementView> listOfAdvertisement = new ArrayList<>();
		String selectQuery = "SELECT advertisement_title FROM advertisement WHERE category_id = '" + category_id + "'";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(selectQuery);

			ResultSet result = statement.executeQuery();

			while (result.next()) {
				String name = result.getString("advertisement_title");

				AdvertisementView advertisement = new AdvertisementView(name);

				listOfAdvertisement.add(advertisement);
			}

			connection.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

		return listOfAdvertisement;
	}

	@Override
	public void deleteById(int id) {
		String deleteQuery = "DELETE FROM advertisement WHERE id='" + id + "' ";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(deleteQuery);

			statement.executeUpdate();

			connection.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
