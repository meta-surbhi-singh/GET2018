package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.models.Category;

//Class to execute queries used for category table
public class CategoryQueryExecution implements ICategoryDao {

	public static CategoryQueryExecution category = new CategoryQueryExecution();
	Connection connection;

	public static CategoryQueryExecution getInstance() {
		return category;
	}

	@Override
	public List<Category> getlist() {
		List<Category> listOfCategory = new ArrayList<Category>();

		String selectQuery = "SELECT * FROM category";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(selectQuery);

			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				int id = resultSet.getInt("ID");
				String name = resultSet.getString("CATEGORY_NAME");

				Category category = new Category(name);
				category.setId(id);

				listOfCategory.add(category);
			}

			connection.close();
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}

		return listOfCategory;
	}

	@Override
	public void insert(Category category) {
		String insertQuery = "INSERT INTO CATEGORY (CATEGORY_NAME) VALUES(?) ";
		connection = ConnectionFactory.getConnection();
		System.out.println(category.getName());

		try {
			PreparedStatement statement = connection.prepareStatement(insertQuery);

			statement.setString(1, category.getName());

			statement.executeUpdate();

			connection.close();
		}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

	@Override
	public void update(Category category) {
		String updateQeury = "UPDATE category SET CATEGORY_NAME = ? WHERE ID=? ";

		connection = ConnectionFactory.getConnection();

		try {
			PreparedStatement statement = connection.prepareStatement(updateQeury);

			statement.setString(1, category.getName());
			statement.setInt(2, category.getId());

			statement.executeUpdate();

			connection.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean CheckCategory(String name) {
		boolean status = false;
		String checkEmailQuery = "SELECT * FROM category WHERE CATEGORY_NAME = '" + name
				+ "'";

		connection = ConnectionFactory.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(checkEmailQuery);

			ResultSet result = statement.executeQuery();

			if (result.next()) {
				status = true;
			}

		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

		return status;
	}

	@Override
	public void deleteById(int id) {
		String deleteQuery = "DELETE FROM category WHERE ID='"+id+"' ";

		connection = ConnectionFactory.getConnection();
		
		try {
			PreparedStatement statement = connection.prepareStatement(deleteQuery);
			
			statement.executeUpdate();
			
			connection.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Category t) {
		
	}
}
