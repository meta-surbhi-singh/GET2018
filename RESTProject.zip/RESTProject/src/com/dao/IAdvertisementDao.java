package com.dao;

import java.util.List;

import com.view.AdvertisementView;

public interface IAdvertisementDao extends IBaseDao<com.models.Advertisement> {

	public boolean CheckAdvertisement(String name);

	public List<AdvertisementView> getListById(int category_id);

	public void deleteById(int id);
}
