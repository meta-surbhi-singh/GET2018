package com.factory;

import com.dao.AdvertisementQueryExecution;
import com.dao.IBaseDao;
import com.dao.CategoryQueryExecution;

import com.enums.EntityName;

public class DaoFactory {

	@SuppressWarnings("rawtypes")
	public static IBaseDao getDaoForEntity(EntityName entityName) {
		IBaseDao basedao = null;
		switch (entityName) {
		case CATEGORY:
			basedao = CategoryQueryExecution.getInstance();
			break;
		case ADVERTISEMENT:
			basedao = AdvertisementQueryExecution.getInstance();
			break;
		}
		return basedao;
	}
}
