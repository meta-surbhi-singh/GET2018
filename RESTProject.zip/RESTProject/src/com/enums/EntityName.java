package com.enums;

public enum EntityName {
	CATEGORY, ADVERTISEMENT;
}
