package com.enums;

public enum Status {
	OK, DUPLICATE, ERROR, NOT_FOUND, CREATED, UPDATED, DELETED, FOUND;
}
