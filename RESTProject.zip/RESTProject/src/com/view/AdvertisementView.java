package com.view;

public class AdvertisementView {

	private String title;

	// Constructor to initialize the attributes
	public AdvertisementView(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
}
