package com.facade;

import java.util.List;

import com.dao.UserQueryExecutionDao;
import com.enums.Status;
import com.model.User;

public class UserFacade {
	
	public static Status createUser(User user) {
		if(!UserQueryExecutionDao.exists(user.getEmail())) {
			UserQueryExecutionDao.insert(user);
			return Status.OK;
		}
		else {
			return Status.DUPLICATE;
		}
	}
	
	private static Status authenticateLogin(String email, String password) {
		if(UserQueryExecutionDao.exists(email)) {
			if(UserQueryExecutionDao.passwordEquals(email, password)) {
				return Status.OK;
			}
			else {
				return Status.ERROR;
			}
		}
		else {
		return Status.NOT_FOUND;
	}
	}

	public static User getLoginUser(String email, String password) {
		User user = null;
		if(authenticateLogin(email,password) == Status.OK) {
			user = UserQueryExecutionDao.selectUser(email);
		}
		return user;
	}
	
	public static List<User> getUserFriends(User user) {
		return UserQueryExecutionDao.selectFriends(user.getEmail(), user.getOrganization());	
	}
	
	public static User getUser(String email) {
		return UserQueryExecutionDao.selectUser(email);
	}
	
	public static Status updateUser(User user) {
		if(UserQueryExecutionDao.updateAll(user)) {
			return Status.UPDATED;
		}
		else {
			return Status.ERROR;
		}
	}
}
