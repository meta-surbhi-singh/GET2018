
package com.filters;

import java.io.IOException;

import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class RegistrationFilter implements Filter {

	/**
	 * Default constructor.
	 */
	public RegistrationFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		RequestDispatcher requestdispatch = request.getRequestDispatcher("UserRegistration.jsp");

		String firstname = request.getParameter("First_Name");
		String lastname = request.getParameter("Last_Name");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		String email = request.getParameter("email");

		if (firstname == null && lastname == null && password == null && confirmpassword == null && email == null) {
			String messageToDisplay = "!! ALL Fields Can't be Blank !!";
			request.setAttribute("message", messageToDisplay);
			requestdispatch.forward(request, response);
		}
		else if (!Pattern.matches("(^[A-Za-z]+$)", firstname) || firstname.length() < 3 || firstname == null) {
			String messageToDisplay = "!! Invalid First name !!";
			request.setAttribute("message", messageToDisplay);
			requestdispatch.forward(request, response);
		} 
		else if (!Pattern.matches("(^[A-Za-z]+$)", lastname) || lastname.length() < 3 || lastname == "") {
			String messageToDisplay = "!! Invalid LastName !!";
			request.setAttribute("message", messageToDisplay);
			requestdispatch.forward(request, response);
		}
		else if (!confirmpassword.equals(password)) {
			System.out.println(confirmpassword + "    " + password);
			String messageToDisplay = "!! Confirm Password And Password Doesnot Match !!";
			request.setAttribute("message", messageToDisplay);
			requestdispatch.forward(request, response);
		} 
		else {
			chain.doFilter(request, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
