package com.servlets;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.enums.Status;
import com.facade.UserFacade;
import com.model.User;

public class RegistrationServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RegistrationServlet() {
		super();
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		String firstName = request.getParameter("First_Name");
		String lastName = request.getParameter("Last_Name");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date;
		try {
			//PrintWriter out = response.getWriter();
			date = new Date(sdf.parse(request.getParameter("date")).getTime());
			int age = Integer.parseInt(request.getParameter("age"));
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String organization = request.getParameter("Organization");
			User user = new User(firstName,lastName, date, age, email, password, organization);
			Status createStatus = UserFacade.createUser(user);
			request.setAttribute("status", createStatus);
			request.setAttribute("user", user);
			RequestDispatcher reqDis = request.getRequestDispatcher("Registration.jsp");
			reqDis.forward(request, response);
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
