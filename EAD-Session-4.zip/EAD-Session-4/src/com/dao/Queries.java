package com.dao;

public class Queries {
	public static final String insertQuery = "INSERT INTO user (first_Name, last_Name, dob, age, email, password, organization) VALUES (?, ?, ?, ?, ?, ?, ?);" ;

	public static final String selectWithEmailQuery = "SELECT * FROM User WHERE Email = ?";
	
	public static final String selectQuery = "SELECT * FROM user";
	
	public static final String selectPasswordQuery ="SELECT password FROM user WHERE email = ?";
	
	public static final String selectWithOrganizationQuery = "SELECT * FROM User WHERE email != ? AND organization = ?";

	public static final String updateAllQuery = "UPDATE user SET first_name = ?, last_name = ?, dob = ?, age= ?, organization =? WHERE Email = ?";

}
