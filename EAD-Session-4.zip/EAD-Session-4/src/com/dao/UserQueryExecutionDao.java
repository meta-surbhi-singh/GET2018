package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.User;

/**
 * @author Surbhi singh
 *
 */
public class UserQueryExecutionDao {
	
	public static int insert(User user) {
		int result = 0;
		try (
				Connection conn = MyConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(Queries.insertQuery); ) {
			    stmt.setString(1,user.getFirst_Name());
			    stmt.setString(2,user.getLast_Name());
			    stmt.setDate(3,user.getDob());
			    stmt.setInt(4, user.getAge());
			    stmt.setString(5, user.getEmail());
			    stmt.setString(6, user.getPassword());
			    stmt.setString(7, user.getOrganization());
				result = stmt.executeUpdate();
			} 
		catch (SQLException ex) {
				ex.printStackTrace();
			}
		return result;
	}

	public static boolean exists(String email) {
		try ( Connection conn = MyConnectionManager.getConnection();
			  PreparedStatement stmt = conn.prepareStatement(Queries.selectWithEmailQuery);) {
			stmt.setString(1, email);
			ResultSet rset = stmt.executeQuery();
			if(!rset.next()) {
				return false;
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		return true;
	}

	public static boolean passwordEquals(String email,String password) {
		try ( Connection conn = MyConnectionManager.getConnection();
			PreparedStatement stmt = conn.prepareStatement(Queries.selectPasswordQuery);) {
			stmt.setString(1, email);
			
			ResultSet rset = stmt.executeQuery();
			rset.next();
			String originalPassword = rset.getString("password");
			if(originalPassword.equals(password)) {
				return true;
			}
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}
	
	public static User selectUser(String email) {
		User user = null;
		try ( Connection conn = MyConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(Queries.selectWithEmailQuery);) {
				stmt.setString(1, email);
				ResultSet rset = stmt.executeQuery();
				rset.next();
				user = new User(rset.getString("first_Name"),rset.getString("last_Name"),rset.getDate("dob"), rset.getInt("age"),rset.getString("email"),rset.getString("password"),rset.getString("organization"));	
			}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
			return user;
	}
	
	public static List<User> selectFriends(String email,String organization) {
		List<User> friends = new ArrayList<User>();
		try ( Connection conn = MyConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(Queries.selectWithOrganizationQuery);) {
				stmt.setString(1, email);
				stmt.setString(2, organization);
				ResultSet rset = stmt.executeQuery();
				while(rset.next()) {
					friends.add(new User(rset.getString("first_Name"),rset.getString("last_Name"),rset.getDate("dob"), rset.getInt("age"),rset.getString("email"),rset.getString("password"),rset.getString("organization")));
				}
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		return friends;		
	}

	public static boolean updateAll(User user) {
		boolean updated = false;
		int result;
		try ( Connection conn = MyConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(Queries.updateAllQuery);) {
			    stmt.setString(1,user.getFirst_Name());
			    stmt.setString(2, user.getLast_Name());
			    stmt.setDate(3, user.getDob());
			    stmt.setInt(4, user.getAge());
			    stmt.setString(5,user.getOrganization());
			    stmt.setString(6,user.getEmail());
				result = stmt.executeUpdate();
				if(result !=0) {
					updated = true;
				}
			}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
			return updated;
	}
}
