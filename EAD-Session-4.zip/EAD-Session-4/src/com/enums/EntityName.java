package com.enums;

public enum EntityName {
    USER;
}
