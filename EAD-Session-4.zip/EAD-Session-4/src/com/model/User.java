package com.model;

import java.sql.Date;
import java.util.List;

/**
 * @author Surbhi singh
 *
 */
public class User {
	String id;
	String first_Name;
	String last_Name;
	Date dob;
	int age;
	String email;
	String password;
	String organization;
	List<User> friends;
	
	
	/**
	 * @param first_Name
	 * @param last_Name
	 * @param dob
	 * @param age
	 * @param email
	 * @param password
	 * @param organization
	 */
	public User(String first_Name, String last_Name, Date dob, int age, String email, String password,
			String organization) {
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.dob = dob;
		this.age = age;
		this.email = email;
		this.password = password;
		this.organization = organization;
		friends = null;
	}

	/**
	 * @return the first_Name
	 */
	public String getFirst_Name() {
		return first_Name;
	}

	/**
	 * @param first_Name the first_Name to set
	 */
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}

	/**
	 * @return the last_Name
	 */
	public String getLast_Name() {
		return last_Name;
	}

	/**
	 * @param last_Name the last_Name to set
	 */
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return first_Name +  " " + last_Name ;
	}

	/**
	 * @return the friends
	 */
	public List<User> getFriends() {
		return friends;
	}

	/**
	 * @param friends the friends to set
	 */
	public void setFriends(List<User> friends) {
		this.friends = friends;
	}	
}
