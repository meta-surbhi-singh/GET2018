/**
 * Triangle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package DefaultNamespace;

public interface Triangle extends java.rmi.Remote {
    public double area(double side1, double side2, double side3) throws java.rmi.RemoteException;
}
