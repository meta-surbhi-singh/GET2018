package com.metacube.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.metacube.training.model.Employee;
import com.metacube.training.service.EmployeeServiceImpl;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private EmployeeServiceImpl employeeService;

	@GetMapping("/login")
	public String login() {
		return "admin/login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam(name = "username") String username,@RequestParam(name = "password") String password) {
		return new ModelAndView("admin/dashboard", "username", username);
	}

	
	//Add employee function
	@RequestMapping(value = "/saveemployee", method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee") Employee employee) {
		if(employee != null && employee.getEmployeeId() == 0) {
			employeeService.createEmployee(employee);
		} else {
			employeeService.updateEmployee(employee);
		}
		return "redirect:/admin/employee";
	}
	
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public String employee(Model model) {
		model.addAttribute("employees", employeeService.getAllEmployee());
		return "admin/employee";
	}
	
	@RequestMapping(value ="/addEmployee", method = RequestMethod.GET)
	public String addEmployee(Model model) {
		model.addAttribute("employee", new Employee());
		return "admin/editEmployee";
	}
	
	@RequestMapping(value = "/editEmployee", method = RequestMethod.GET)
	public String editEmployee(Model model, @RequestParam("id") int id) {
		model.addAttribute("employee", employeeService.getEmployeeById(id));
		return "admin/editEmployee";
	}
	
	@RequestMapping(value = "/deleteEmployee", method = RequestMethod.GET)
	public String deleteEmployee(Model model, @RequestParam("id") int id) {
		employeeService.deleteEmployee(id);
		return "redirect:/admin/employee";
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search() {
		return "admin/search";
	}
	
	@RequestMapping(value = "/searchEmployee", method = RequestMethod.POST)
	public String searchEmployee(Model model, @RequestParam("name") String name) {
		model.addAttribute("employees", employeeService.searchEmployee(name));
		model.addAttribute("name", name);
		return "admin/searchEmployee";
	}
	
	@RequestMapping(value = "/back", method = RequestMethod.GET)
	public String back() {
		return "redirect:./login";
	}
}
