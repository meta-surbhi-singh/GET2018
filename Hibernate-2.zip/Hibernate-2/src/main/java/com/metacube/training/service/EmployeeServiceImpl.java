package com.metacube.training.service;

import java.util.List;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.metacube.training.model.Employee;
import com.metacube.training.repository.CRUDRepository;

@Component
@Service
public class EmployeeServiceImpl {
	
	@Autowired
	CRUDRepository repository;


	public boolean createEmployee(Employee employee) {
		return repository.save(employee) != null;
	}

	public boolean updateEmployee(Employee employee) {
		return repository.saveAndFlush(employee) != null;
	}

	public Employee getEmployeeById(int id) {
		return repository.findByEmployeeId(id);
	}

	public boolean deleteEmployee(int id) {
		repository.delete(id);
		return true;
	}

	public List<Employee> getAllEmployee() {
		return repository.findAll();	}

	public Employee getEmployeeByEmail(String email) {
		return repository.findByEmailId(email);
	}

	public boolean employeeAuthenticated(String email, String password) {
		if(getEmployeeByEmail(email) != null) {
			if(getEmployeeByEmail(email).getPassword().equals(password)) {
			    return true;
			}
			else
				return false;
		}
		else {
			return false;
		}
	}

	public void sendResetLink(String email) {
		String to = "surbhi.singh@metacube.com";
		String from = "dummy@gmail.com";
		String password = "mayankji";
		String host = "localhost";
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		properties.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.setProperty("mail.smtp.socketFactory.fallback", "false");
		properties.setProperty("mail.smtp.port", "465");
		properties.setProperty("mail.smtp.socketFactory.port", "465");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.debug", "true");
		properties.put("mail.store.protocol", "pop3");
		properties.put("mail.transport.protocol", "smtp");
		
		Session session = Session.getInstance(properties,new Authenticator(){protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(from, password);}});
		System.out.println("send reset  link method  " + email);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject("password reset");
			message.setText("this is your new password : xyz");
			resetPassword();
			Transport.send(message);

			System.out.println("message sent successfully");
		} catch (MessagingException me) {
			me.printStackTrace();

		}

	}

	private void resetPassword() {
		System.out.println("password reset");

	}
	
	public List<Employee> searchEmployee(String name){
		return repository.searchByName(name);
	}

}
