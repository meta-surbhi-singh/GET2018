package com.metacube.training.SpringBootProject.dao;

import java.util.List;

import com.metacube.training.SpringBootProject.model.Employee;

public interface EmployeeDao {

	public List<Employee> getlist();

	public boolean insert(Employee employee);

	public int update(Employee employee);

	public boolean delete(Employee employee);
	
	public Employee search(String firstName, String lastName);
	
	public Employee getEmployeeById(int id);
}
