package com.metacube.training.SpringBootProject.service;

import java.util.List;

import com.metacube.training.SpringBootProject.model.Employee;

public interface EmployeeService {
	
	public boolean updateEmployee(Employee employee);
	public Employee searchEmployee(String firstName, String lastName);
	public boolean createEmployee(Employee employee);
	public Object getEmployeeById(int id);
	public boolean deleteEmployee(int id);
	public List<Employee> getAllEmployee();

}
