package com.metacube.training.SpringBootProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.metacube.training.SpringBootProject.dao.SkillDAO;
import com.metacube.training.SpringBootProject.model.Skill;

@Service
public class SkillServiceImpl implements SkillService {

	@Autowired
	private SkillDAO skillDAO;
	
	@Override
	public Skill getSkillById(int id) {
		return skillDAO.getSkillById(id);
	}

	@Override
	public List<Skill> getAllSkill() {
		return skillDAO.getAllSkill();
	}

	@Override
	public boolean deleteSkill(int id) {
	Skill skill = skillDAO.getSkillById(id);
	return skillDAO.deleteSkill(skill);
	}

	@Override
	public boolean updateSkill(Skill skill) {
		return skillDAO.updateSkill(skill);
	}

	@Override
	public boolean createSkill(Skill skill) {
		System.out.println(skill + " in the service method");
		return skillDAO.createSkill(skill);
	}

	
}
