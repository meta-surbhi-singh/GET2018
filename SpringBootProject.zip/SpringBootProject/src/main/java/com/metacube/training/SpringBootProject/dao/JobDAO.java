package com.metacube.training.SpringBootProject.dao;

import java.util.List;

import com.metacube.training.SpringBootProject.model.Job;

public interface JobDAO {
	Job getJobById(int id);

	List<Job> getAllJobs();

	boolean deleteJob(Job job);

	boolean updateJob(Job job);

	boolean createJob(Job job);
}
