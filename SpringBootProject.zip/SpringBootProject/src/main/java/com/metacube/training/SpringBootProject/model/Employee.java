package com.metacube.training.SpringBootProject.model;



import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Employee {

	private int employee_id;
	private String firstname;
	private String lastname;
	@DateTimeFormat(pattern= "yyyy-MM-dd")
	private Date dateOfBirth;
	private String skills;
	private String gender;
	private String primarycontact;
	private String secondarycontact;
	private String email;
	private String skypeId;
	private String profileImage;
	private String password;

	// Getters and Setters

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int id) {
		this.employee_id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrimarycontact() {
		return primarycontact;
	}

	public void setPrimarycontact(String primarycontact) {
		this.primarycontact = primarycontact;
	}

	public String getSecondarycontact() {
		return secondarycontact;
	}

	public void setSecondarycontact(String secondarycontact) {
		this.secondarycontact = secondarycontact;
	}

	
	public String getSkypeId() {
		return skypeId;
	}

	public void setSkypeId(String skypeId) {
		this.skypeId = skypeId;
	}

	// Getters and Setters End
}
