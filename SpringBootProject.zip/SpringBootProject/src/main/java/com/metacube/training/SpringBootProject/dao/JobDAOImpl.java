package com.metacube.training.SpringBootProject.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.training.SpringBootProject.mappers.JobMapper;
import com.metacube.training.SpringBootProject.model.Job;

@Repository
public class JobDAOImpl implements JobDAO{
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	public JobDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private final String selectQuery = "select * from job where id = ?";
	private final String selectAll = "select * from job";
	private final String updateQuery = "update job set job_Detail = ? where id = ?";
	private final String deleteQuery = "delete from job where id = ?";
	private final String insertQuery = "insert into job(job_Detail) values (?)";
	@Override
	public Job getJobById(int id) {
		return jdbcTemplate.queryForObject(selectQuery, new Object[] {id}, new JobMapper());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Job> getAllJobs() {
		return jdbcTemplate.query(selectAll, new JobMapper());
	}

	@Override
	public boolean deleteJob(Job job) {
		return jdbcTemplate.update(deleteQuery, job.getId() ) > 0;

	}

	@Override
	public boolean updateJob(Job job) {
		return jdbcTemplate.update(updateQuery, job.getJob(), job.getId()) > 0;
	}

	@Override
	public boolean createJob(Job job) {
		return jdbcTemplate.update(insertQuery, job.getJob()) > 0;
	}

}
