package com.metacube.training.SpringBootProject.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.metacube.training.SpringBootProject.model.Employee;


public class EmployeeMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee = new Employee();
		employee.setEmployee_id(rs.getInt("employee_id"));
		employee.setFirstname(rs.getString("first_name"));
		employee.setLastname(rs.getString("last_name"));
		employee.setDateOfBirth(rs.getDate("dob"));
		employee.setGender(rs.getString("gender"));
		employee.setPrimarycontact(rs.getString("primary_contact_number"));
		employee.setSecondarycontact(rs.getString("secondary_contact_number"));
		employee.setEmail(rs.getString("email_id"));
		employee.setProfileImage(rs.getString("profile_image"));
		employee.setSkypeId(rs.getString("skype_id"));
		employee.setPassword(rs.getString("password"));
		return employee;
	}
}
