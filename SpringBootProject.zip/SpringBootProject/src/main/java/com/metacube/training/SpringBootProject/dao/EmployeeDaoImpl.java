package com.metacube.training.SpringBootProject.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.training.SpringBootProject.mappers.EmployeeMapper;
import com.metacube.training.SpringBootProject.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	private final String selectAll = "select * from employees";
	private final String selectById = "select * from employees where employee_id = ?";
	private final String deleteQuery = "delete from employees where employee_id = ?";
	private final String updateQuery = "update employees set first_name = ?, last_name = ?, dob = ?, gender = ?, primary_contact_number = ?, secondary_contact_number = ?, email_id = ?, skype_id = ?, profile_image = ? , password = ? where employee_id = ? ";
	private final String insertQuery = "insert into employees(first_name, last_name, dob, gender , primary_contact_number, secondary_contact_number, email_id, skype_id, profile_image ,password) values(?,?,?,?,?,?,?,?,?,?)";
	private final String searchByNameQuery = "select * from employees where first_name = ? and last_name = ?";
	@Override
	public List<Employee> getlist() {
		return jdbcTemplate.query(selectAll, new EmployeeMapper());
	}

	@Override
	public boolean insert(Employee employee) {
		return jdbcTemplate.update(insertQuery, employee.getFirstname(), employee.getLastname(),employee.getDateOfBirth(),employee.getGender(),employee.getPrimarycontact(),employee.getSecondarycontact(),employee.getEmail(),employee.getSkypeId(),employee.getProfileImage(),employee.getPassword()) > 0;		
	}

	@Override
	public int update(Employee employee) {
		return jdbcTemplate.update(updateQuery, employee.getFirstname(), employee.getLastname(), employee.getDateOfBirth(), employee.getGender(), employee.getPrimarycontact(), employee.getSecondarycontact(), employee.getEmail(), employee.getSkypeId(),employee.getProfileImage(), employee.getPassword(), employee.getEmployee_id());
		
	}

	@Override
	public boolean delete(Employee employee) {
		return jdbcTemplate.update(deleteQuery, employee.getEmployee_id()) > 0;
	}

	@Override
	public Employee search(String firstName, String lastName) {
		return jdbcTemplate.queryForObject(searchByNameQuery, new Object[] {firstName, lastName}, new EmployeeMapper());
	}

	@Override
	public Employee getEmployeeById(int id) {
		return jdbcTemplate.queryForObject(selectById, new Object []{id},new EmployeeMapper());
	} 
		
}
