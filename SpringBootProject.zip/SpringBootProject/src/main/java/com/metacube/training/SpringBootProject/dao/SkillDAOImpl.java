package com.metacube.training.SpringBootProject.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.training.SpringBootProject.mappers.SkillMapper;
import com.metacube.training.SpringBootProject.model.Skill;

@Repository
public class SkillDAOImpl implements SkillDAO{
	
	JdbcTemplate jdbcTemplate;
	@Autowired 
	public SkillDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	private final String selectQuery = "select * from skill where skill_id = ?";
	private final String selectAll = "select * from skill";
	private final String insertQuery = "insert into skill(skill_name) values (?) ";
	private final String deleteQuery = "delete from skill where skill_id = ?";
	private final String updateQuery = "update skill set skill_name = ? where skill_id = ?";
	
	@Override
	public Skill getSkillById(int id) {
		return jdbcTemplate.queryForObject(selectQuery, new Object[] {id}, new SkillMapper());
	}

	@Override
	public List<Skill> getAllSkill() {
		return jdbcTemplate.query(selectAll, new SkillMapper());
		}

	@Override
	public boolean deleteSkill(Skill skill) {
		return jdbcTemplate.update(deleteQuery, skill.getId()) > 0;
	}

	@Override
	public boolean updateSkill(Skill skill) {
		return jdbcTemplate.update(updateQuery, skill.getName(),skill.getId()) > 0;
	}

	@Override
	public boolean createSkill(Skill skill) {
		return jdbcTemplate.update(insertQuery, skill.getName()) > 0;
	}

	
}
