package com.metacube.training.SpringBootProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.metacube.training.SpringBootProject.dao.EmployeeDaoImpl;
import com.metacube.training.SpringBootProject.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDaoImpl employeeDao;

	@Override
	public boolean createEmployee(Employee employee) {
		return employeeDao.insert(employee);
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		return employeeDao.update(employee) > 0;
	}

	@Override
	public Employee searchEmployee(String firstName, String lastName) {
		return employeeDao.search(firstName,lastName);
	}

	@Override
	public Employee getEmployeeById(int id) {
		return employeeDao.getEmployeeById(id);
	}


	@Override
	public boolean deleteEmployee(int id) {
		Employee employee = employeeDao.getEmployeeById(id);
		return employeeDao.delete(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		return employeeDao.getlist();
	}
 

}
