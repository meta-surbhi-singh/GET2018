'use strict';

angular.module('core').
    filter('category',function(){
        return function(input){
            
        }
    });