'use strict';

angular.module('core',[]);