'use strict';

angular.module('cartDetail',[
    'ngRoute'
]);