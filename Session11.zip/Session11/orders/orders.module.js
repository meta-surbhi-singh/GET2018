'use strict';

angular.module('orders',[
    'ngRoute'
]);