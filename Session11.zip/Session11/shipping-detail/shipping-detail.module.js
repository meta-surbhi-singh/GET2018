'use strict';

angular.module('shippingDetail',[
    'ngRoute'
]);