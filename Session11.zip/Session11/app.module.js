angular.module('shoppingApp',[
    'ngRoute',
    'productList',
    'cartDetail',
    'shippingDetail',
    'orderSuccess',
    'orders'
]);