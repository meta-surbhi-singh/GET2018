'use strict';

angular.module('orderSuccess',[
    'ngRoute'
]);