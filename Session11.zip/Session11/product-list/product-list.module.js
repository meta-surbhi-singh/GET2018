'use strict';

angular.module('productList',[
    'ngRoute'
]);